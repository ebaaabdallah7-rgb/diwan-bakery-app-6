#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
APP="../app/src/main/assets/www"
node --check "$APP/core.js"
node --check "$APP/advanced.js"
node --check "$APP/app.js"
node tests.js
node tests_v03.js
node tests_v05.js
