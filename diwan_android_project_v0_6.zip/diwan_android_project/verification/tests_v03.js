const assert=require('assert');require('./core.js');require('./advanced.js');const C=global.DiwanCore;let s=C.blank();C.initAdvanced(s);const date='2026-11-22';
// Raw stock, purchase return, inventory count
let m=C.addMaterial(s,{name:'طحين',unit:'غرام',openingQty:100000,openingCost:1,date});
let pur=C.purchase(s,{date,materialId:m.id,qty:1,factor:50000,buyUnit:'شوال',total:50000,payment:'نقداً'});
let pr=C.purchaseReturn(s,{date,purchaseId:pur.id,qty:5000});assert.equal(pur.returnedQty,5000);
let before=C.rawQty(s,m.id);let sc=C.stockCount(s,{date,materialId:m.id,actualQty:before-100,reason:'عينة جرد'});assert.equal(sc.difference,-100);
// Expense allocation, employee payroll, advances, currency ledger
let alloc=C.allocateExpense(s,{date,kind:'ديزل المولدة',basis:'ساعات تشغيل',amount:10000,payment:'نقداً',rows:[{department:'قسم الكيك',weight:6},{department:'قسم المعجنات',weight:4}]});assert.equal(alloc.allocations.reduce((a,x)=>a+x.amount,0),10000);
let emp=C.addEmployee(s,{name:'موظف تجريبي',salary:100000,department:'قسم الكيك'});let pay=C.payrollAccrue(s,{date,month:'2026-11',employeeId:emp.id,gross:100000,deductions:10000});assert.equal(pay.net,90000);C.payrollPay(s,{date,payrollId:pay.id,amount:90000,method:'نقداً'});C.employeeAdvance(s,{date,employeeId:emp.id,amount:5000,method:'نقداً'});
C.addCurrency(s,{code:'USD',name:'دولار أمريكي'});let fx=C.foreignJournal(s,{date,amount:10,currency:'USD',rate:1300,debitAccount:'1000',creditAccount:'3000',description:'اختبار صرف'});assert.equal(fx.base,13000);
// Finished goods and van reconciliation
let p=C.addProduct(s,{name:'خبز تجريبي',department:'قسم الخبز العيش',unit:'قطعة',yieldQty:1,recipe:[{materialId:m.id,qty:100}]});C.produce(s,{date,productId:p.id,qty:20});C.transfer(s,{date,productId:p.id,qty:10,from:'production',to:'van'});let sale=C.sell(s,{date,productId:p.id,channel:'سيارة جملة',qty:2,price:1000,payment:'نقداً',routeId:'R-01'});assert.equal(sale.routeId,'R-01');let run=C.vanRun(s,{date,productId:p.id,routeId:'R-01',loaded:10,sold:2,goodReturn:3,damaged:1,shortage:4});assert.equal(run.variance,0);
// Reject inconsistent vehicle reconciliation and purchase over-return
assert.throws(()=>C.vanRun(s,{date,productId:p.id,routeId:'R-02',loaded:10,sold:2,goodReturn:1,damaged:1,shortage:1}));
assert.throws(()=>C.purchaseReturn(s,{date,purchaseId:pur.id,qty:999999}));
// Close period, prevent posting and integrity-check backup
let close=C.closePeriod(s,{from:date,to:date});assert.ok(close.hash);assert.throws(()=>C.journal(s,{date,description:'محاولة بعد الإقفال',lines:[{account:'1000',debit:1,credit:0},{account:'3000',debit:0,credit:1}]}));let rawAfterClose=C.rawQty(s,m.id);assert.throws(()=>C.purchase(s,{date,materialId:m.id,qty:1,factor:1,buyUnit:'وحدة',total:1,payment:'نقداً'}));assert.equal(C.rawQty(s,m.id),rawAfterClose);
let b=C.backupAdvanced(s);let restored=C.restoreCheck(JSON.parse(JSON.stringify(b)));assert.equal(restored.closedPeriods.length,1);let corrupt=JSON.parse(JSON.stringify(b));corrupt.state.materials[0].name='تغيير';assert.throws(()=>C.restoreCheck(corrupt));let noChecksum=JSON.parse(JSON.stringify(b));delete noChecksum.checksum;assert.throws(()=>C.restoreCheck(noChecksum));
assert.equal(C.trialBalance(s).totalDebit,C.trialBalance(s).totalCredit);assert.ok(Math.abs(C.balanceSheet(s).difference)<0.01);assert.equal(C.validateAdvanced(s).ok,true);
console.log('PASS 19 assertions; journals='+s.journals.length+'; TB difference='+(C.trialBalance(s).totalDebit-C.trialBalance(s).totalCredit)+'; BS difference='+C.balanceSheet(s).difference);
