const assert=require('assert');
require('./core.js');require('./advanced.js');const C=global.DiwanCore;
const d='2026-11-22';let s=C.blank();C.initAdvanced(s);
// Date validation must reject impossible calendar dates.
assert.throws(()=>C.journal(s,{date:'2026-02-31',description:'bad date',lines:[{account:'1000',debit:1,credit:0},{account:'3000',debit:0,credit:1}]}));
// Reject zero-cost opening stock/purchases before changing balances.
let invalidStock=C.blank();C.initAdvanced(invalidStock);assert.throws(()=>C.addMaterial(invalidStock,{name:'مادة صفرية',unit:'غرام',openingQty:5,openingCost:0,date:d}));assert.equal(invalidStock.materials.length,0);
let testMat=C.addMaterial(invalidStock,{name:'مادة اختبار',unit:'غرام'});assert.throws(()=>C.purchase(invalidStock,{date:d,materialId:testMat.id,qty:1,factor:1000,total:0,payment:'نقداً'}));assert.equal(C.rawQty(invalidStock,testMat.id),0);
// Payroll deductions are a liability, and partial salary payments can be completed.
let emp=C.addEmployee(s,{name:'موظف',salary:100000,department:'قسم الكيك'});
let pay=C.payrollAccrue(s,{date:d,month:'2026-11',employeeId:emp.id,gross:100000,deductions:10000});
assert.equal(pay.net,90000);assert.throws(()=>C.payrollAccrue(s,{date:d,month:'2026-11',employeeId:emp.id,gross:100000,deductions:0}));
C.payrollPay(s,{date:d,payrollId:pay.id,amount:30000});assert.equal(pay.status,'partial');
C.payrollPay(s,{date:d,payrollId:pay.id,amount:60000});assert.equal(pay.status,'paid');assert.equal(pay.paid,90000);
// Customer credit balance must not be reduced by a cash-sale return.
let m=C.addMaterial(s,{name:'طحين',unit:'غرام',openingQty:10000,openingCost:1,date:d});
let p=C.addProduct(s,{name:'خبز',department:'قسم الخبز العيش',unit:'قطعة',yieldQty:1,recipe:[{materialId:m.id,qty:10}]});
C.produce(s,{date:d,productId:p.id,qty:110});C.transfer(s,{date:d,productId:p.id,qty:100,from:'production',to:'hall'});
let cust={id:C.id(),name:'عميل'};s.customers.push(cust);
let cashSale=C.sell(s,{date:d,productId:p.id,channel:'الصالة',qty:10,price:1000,payment:'نقداً'});
let creditSale=C.sell(s,{date:d,productId:p.id,channel:'الصالة',qty:10,price:1000,payment:'آجل',customerId:cust.id});
assert.equal(C.customerDue(s,cust.id),10000);
C.saleReturn(s,{date:d,saleId:cashSale.id,qty:1,condition:'سليم',method:'نقداً'});
assert.equal(C.customerDue(s,cust.id),10000);
C.saleReturn(s,{date:d,saleId:creditSale.id,qty:2,condition:'سليم'});
assert.equal(C.customerDue(s,cust.id),8000);
// A vehicle run needs a route id and cannot be reconciled twice.
C.transfer(s,{date:d,productId:p.id,qty:10,from:'production',to:'van'});
let vanSale=C.sell(s,{date:d,productId:p.id,channel:'سيارة جملة',qty:2,price:1000,payment:'نقداً',routeId:'V-1'});
C.vanRun(s,{date:d,productId:p.id,routeId:'V-1',loaded:10,sold:2,goodReturn:3,damaged:1,shortage:4});
assert.throws(()=>C.vanRun(s,{date:d,productId:p.id,routeId:'V-1',loaded:10,sold:2,goodReturn:3,damaged:1,shortage:4}));
assert.throws(()=>C.vanRun(s,{date:d,productId:p.id,loaded:1,sold:0,goodReturn:1,routeId:''}));
// Purchase return uses original invoice unit value for creditor/cash reversal,
// while separately recording weighted-average inventory carrying value.
let pur=C.purchase(s,{date:d,materialId:m.id,qty:1,factor:1000,buyUnit:'كيس',total:2000,payment:'نقداً'});
let ret=C.purchaseReturn(s,{date:d,purchaseId:pur.id,qty:100});
assert.equal(ret.value,200);assert.ok(Number.isFinite(ret.inventoryValue));
assert.equal(C.trialBalance(s).totalDebit,C.trialBalance(s).totalCredit);
assert.ok(Math.abs(C.balanceSheet(s).difference)<0.01);
assert.equal(C.validate(s).ok,true);assert.equal(C.validateAdvanced(s).ok,true);
console.log('PASS 23 regression assertions; journals='+s.journals.length+'; TB difference='+(C.trialBalance(s).totalDebit-C.trialBalance(s).totalCredit)+'; BS difference='+C.balanceSheet(s).difference);
